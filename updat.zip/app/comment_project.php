<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class comment_project extends Model
{
    //
}
